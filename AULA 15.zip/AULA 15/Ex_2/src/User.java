import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class User {
    private String login;
    private String senha;
    private double P1;
    private double P2;
    private double trabalho;
    private int faltas;

    public User(String login, String senha, double P1, double P2, double trabalho, int faltas) {
        this.login = login;
        this.senha = senha;
        this.P1 = P1;
        this.P2 = P2;
        this.trabalho = trabalho;
        this.faltas = faltas;
    }

    // Getters e Setters

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public double getP1() {
        return P1;
    }

    public void setP1(double P1) {
        this.P1 = P1;
    }

    public double getP2() {
        return P2;
    }

    public void setP2(double P2) {
        this.P2 = P2;
    }

    public double getTrabalho() {
        return trabalho;
    }

    public void setTrabalho(double trabalho) {
        this.trabalho = trabalho;
    }

    public int getFaltas() {
        return faltas;
    }

    public void setFaltas(int faltas) {
        this.faltas = faltas;
    }

    public void incluir(Connection conn) {
        if (exists(conn)) {
            System.out.println("Registro com login " + login + " já existe.");
            return;
        }
        String sqlInsert = "INSERT INTO User(login, senha, P1, P2, trabalho, faltas) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stm = conn.prepareStatement(sqlInsert)) {
            stm.setString(1, getLogin());
            stm.setString(2, getSenha());
            stm.setDouble(3, getP1());
            stm.setDouble(4, getP2());
            stm.setDouble(5, getTrabalho());
            stm.setInt(6, getFaltas());
            stm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }

    public void excluir(Connection conn) {
        String sqlDelete = "DELETE FROM User WHERE login = ?";
        try (PreparedStatement stm = conn.prepareStatement(sqlDelete)) {
            stm.setString(1, getLogin());
            stm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }

    public void atualizar(Connection conn) {
        String sqlUpdate = "UPDATE User SET senha = ?, P1 = ?, P2 = ?, trabalho = ?, faltas = ? WHERE login = ?";
        try (PreparedStatement stm = conn.prepareStatement(sqlUpdate)) {
            stm.setString(1, getSenha());
            stm.setDouble(2, getP1());
            stm.setDouble(3, getP2());
            stm.setDouble(4, getTrabalho());
            stm.setInt(5, getFaltas());
            stm.setString(6, getLogin());
            stm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        }
    }

    public void carregar(Connection conn) {
        String sqlSelect = "SELECT senha, P1, P2, trabalho, faltas FROM User WHERE login = ?";
        PreparedStatement stm = null;
        ResultSet rs = null;

        try {
            stm = conn.prepareStatement(sqlSelect);
            stm.setString(1, getLogin());
            rs = stm.executeQuery();
            if (rs.next()) {
                this.setSenha(rs.getString("senha"));
                this.setP1(rs.getDouble("P1"));
                this.setP2(rs.getDouble("P2"));
                this.setTrabalho(rs.getDouble("trabalho"));
                this.setFaltas(rs.getInt("faltas"));
            } else {
                this.setSenha(null); // Garantir que senha é null se o usuário não existir
                System.out.println("Usuário com login " + login + " não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
            if (stm != null) {
                try {
                    stm.close();
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    private boolean exists(Connection conn) {
        String sqlCheck = "SELECT 1 FROM User WHERE login = ?";
        try (PreparedStatement stm = conn.prepareStatement(sqlCheck)) {
            stm.setString(1, getLogin());
            try (ResultSet rs = stm.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
