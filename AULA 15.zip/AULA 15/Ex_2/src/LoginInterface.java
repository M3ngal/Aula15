import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import javax.swing.*;
import java.util.Locale;
import java.util.ResourceBundle;

public class LoginInterface extends JFrame {
    private JTextField loginField;
    private JPasswordField passwordField;
    private Connection conn;  // Conexão com o banco de dados
    private ResourceBundle bn;

    public LoginInterface(Connection conn) {
        super("Login");
        this.conn = conn;

        int op = Integer.parseInt(JOptionPane.showInputDialog("Idioma - Language \n\n1- Português \n2- English\n "));
        // Carga dos arquivos de internacionalização
        switch(op){
            case 1: bn = ResourceBundle.getBundle("Scr", new Locale("pt", "BR"));
                break;
            case 2: bn = ResourceBundle.getBundle("Scr", Locale.US);
                break;
            default: bn = ResourceBundle.getBundle ("Scr");
                break;
        }

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(5, 10, 5, 10); // Espaçamento entre os componentes
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; // Coluna 0

        // Label para login
        JLabel loginLabel = new JLabel(bn.getString("t1.l.user") + ":");
        gbc.gridy = 0; // Linha 0
        add(loginLabel, gbc);

        // Campo de login
        loginField = new JTextField(18);
        gbc.gridy = 1; // Linha 1
        add(loginField, gbc);

        // Label para senha
        JLabel passwordLabel = new JLabel(bn.getString("t1.l.passw") + ":");
        gbc.gridy = 2; // Linha 2
        add(passwordLabel, gbc);

        // Campo de senha
        passwordField = new JPasswordField(18);
        gbc.gridy = 3; // Linha 3
        add(passwordField, gbc);

        // Botão de envio
        JButton loginButton = new JButton(bn.getString("t1.b.entr"));
        gbc.gridy = 4;
        add(loginButton, gbc);

        // Adiciona ação ao botão de login
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });

        setSize(300, 200);
        setLocationRelativeTo(null); // Centraliza a janela na tela
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void handleLogin() {
        String login = loginField.getText();
        String senha = new String(passwordField.getPassword());

        User user = new User(login, senha, 0, 0, 0, 0);
        user.carregar(conn);

        if (user.getSenha() != null && user.getSenha().equals(senha)) {
            // Se o login e senha forem válidos, abre a interface de edição
            new EditUserInterface(conn, user, bn);
            // Não fecha a janela de login
        } else {
            // Se o login não existe ou a senha estiver incorreta
            JOptionPane.showMessageDialog(this, bn.getString("t1.e.m"), bn.getString("t1.e.t"), JOptionPane.ERROR_MESSAGE);
        }
    }
}
