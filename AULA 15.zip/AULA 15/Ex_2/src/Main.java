import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        Connection conn = null;
        try {
            Connector bd = new Connector();
            conn = bd.conectar();

            // Passe a conexão para a interface de login
            LoginInterface loginInterface = new LoginInterface(conn);

            // Aguarde a interface de login ser fechada
            while (loginInterface.isVisible()) {
                try {
                    Thread.sleep(100); // Verifica a cada 100 ms
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}