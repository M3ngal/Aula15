import javax.swing.JFrame;

public class TelaExemploTest {
    public static void main(String args[]){
        TelaExemplo exemplo = new TelaExemplo();
        exemplo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
